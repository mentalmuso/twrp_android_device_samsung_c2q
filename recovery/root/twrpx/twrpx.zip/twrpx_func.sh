#!/sbin/sh

TPROP=/tmp/twrpx.prop
TWRPXZIP=/tmp/twrpx.zip
MPS=/efs/imei/mps_code.dat
MPS2=/efs/imei/omcnw_code.dat
MPS3=/efs/imei/omcnw_code2.dat
BMPS=/efs/imei/mps_code.bak
BMPS2=/efs/imei/omcnw_code.bak
BMPS3=/efs/imei/omcnw_code2.bak
MAGISK=/tmp/magisk.zip
MODULES=/data/adb/modules
VETC=/vendor/etc
APP=/system_root/system/app
PAPP=/system_root/system/priv-app
DBBACK=/sdcard/TWRP/debloat
SYS=/system_root/system

twrpx_mount ()
{
    if grep -q "system_root" /proc/mounts;  then
        echo " System already mounted"
        mount -o rw,remount /system_root
        sleep 1
        echo " System now mounted RW"
    else
        mount -t ext4 /dev/block/mapper/system /system_root
        echo " System mounted"
        sleep 1
        mount -o rw,remount /system_root
        echo " System now mounted RW"
    fi  
    if grep -q "vendor" /proc/mounts;  then
        echo " Vendor already mounted"
        mount -o rw,remount /vendor
        sleep 1
        echo " Vendor now mounted RW"
    else
        mount -t ext4 /dev/block/mapper/vendor /vendor
        echo " Vendor mounted"
        sleep 1
        mount -o rw,remount /vendor
        echo " Vendor now mounted RW"
    fi
}

twrpx_mount_s ()
{   
    if grep -q "system_root" /proc/mounts;  then
        echo " System already mounted"
        mount -o rw,remount /system_root
        sleep 1
        echo " System now mounted RW"
    else
        mount -t ext4 /dev/block/mapper/system /system_root
        echo " System mounted"
        sleep 1
        mount -o rw,remount /system_root
        echo " System now mounted RW"
    fi 
}

twrpx_mount_v ()
{   
    if grep -q "vendor" /proc/mounts;  then
        echo " Vendor already mounted"
        mount -o rw,remount /vendor
        sleep 1
        echo " Vendor now mounted RW"
    else
        mount -t ext4 /dev/block/mapper/vendor /vendor
        echo " Vendor mounted"
        sleep 1
        mount -o rw,remount /vendor
        echo " Vendor now mounted RW"
    fi 
}

twrpx_umount_full ()
{
    if grep -q "system_root" /proc/mounts;  then
        umount system_root
        mount -t ext4 /dev/block/mapper/system /system_root
        mount -o rw,remount /system_root
        umount system_root
        sleep 1
        echo " System now unmounted"
    else
        mount -t ext4 /dev/block/mapper/system /system_root
        mount -o rw,remount /system_root
        umount system_root
        echo " System already unmounted"
    fi
    if grep -q "vendor" /proc/mounts;  then
        umount vendor
        mount -t ext4 /dev/block/mapper/vendor /vendor
        mount -o rw,remount /vendor
        umount vendor
        sleep 1
        echo " Vendor now unmounted"
    else
        mount -t ext4 /dev/block/mapper/vendor /vendor
        mount -o rw,remount /vendor
        umount vendor
        echo " Vendor already unmounted"
    fi
}

twrpx_umount_full2 ()
{
    echo "twrpx=E" > $TPROP
    twrp install $TWRPXZIP
    twrpx_umount_full
}

twrpx_umount ()
{
    if grep -q "system_root" /proc/mounts;  then
        umount system_root
        sleep 1
        echo " System now unmounted"
    else
        echo " System already unmounted"
    fi
    if grep -q "vendor" /proc/mounts;  then
        umount vendor
        sleep 1
        echo " Vendor now unmounted"
    else
        echo " Vendor already unmounted"
    fi
}

twrpx_umount_s ()
{
    if grep -q "system_root" /proc/mounts;  then
        umount system_root
        sleep 1
        echo " System now unmounted"
    else
        echo " System already unmounted"
    fi
}

twrpx_umount_v ()
{
    if grep -q "vendor" /proc/mounts;  then
        umount vendor
        sleep 1
        echo " Vendor now unmounted"
    else
        echo " Vendor already unmounted"
    fi
}

twrpx_mount_efs ()
{
    mount /dev/block/bootdevice/by-name/sec_efs /efs
}

twrpx_debloat ()
{
if [ ! -d "$DBBACK" ]; then
    mkdir $DBBACK
    mkdir $DBBACK/app
    mkdir $DBBACK/priv-app
fi
if grep -q "twrpx=8" $TPROP; then
    mv $APP/FBAppManager_NS $DBBACK/app
    mv $APP/FlipboardBriefing $DBBACK/app
    mv $APP/GearManagerStub $DBBACK/app
    mv $APP/SamsungPassAutofill_v1 $DBBACK/app
    mv $APP/SBrowser_12* $DBBACK/app
    mv $APP/SmartSwitchAgent $DBBACK/app
    mv $PAPP/OneDrive_Samsung_v3 $DBBACK/priv-app
    mv $PAPP/Tips $DBBACK/priv-app
    mv $PAPP/VZWAPNService_VZW $DBBACK/priv-app
elif grep -q "twrpx=9" $TPROP; then
    mv $APP/DAAgent $DBBACK/app
    mv $APP/BBCAgent $DBBACK/app
    mv $APP/BCService $DBBACK/app
    mv $APP/KnoxAttestationAgent $DBBACK/app
    mv $APP/SecurityLogAgent* $DBBACK/app
    mv $PAPP/ContainerAgent3 $DBBACK/priv-app
    mv $PAPP/DiagMonAgent $DBBACK/priv-app
    mv $PAPP/FotaAgent $DBBACK/priv-app
    mv $PAPP/KLMSAgent $DBBACK/priv-app
    mv $PAPP/knoxanalyticsagent $DBBACK/priv-app
    mv $PAPP/KnoxCore $DBBACK/priv-app
    mv $PAPP/KnoxKeychain $DBBACK/priv-app
    mv $PAPP/knoxvpnproxyhandler $DBBACK/priv-app
    mv $PAPP/SecureFolder $DBBACK/priv-app
    mv $PAPP/SKMSAgent $DBBACK/priv-app
    mv $PAPP/SOAgent $DBBACK/priv-app
    mv $APP/UniversalMDMClient $DBBACK/app
    mv $PAPP/AuthFramework $DBBACK/priv-app
    mv $PAPP/Fast $DBBACK/priv-app
    mv $PAPP/OMCAgent5 $DBBACK/priv-app
    mv $PAPP/PaymentFramework $DBBACK/priv-app
    mv $SYS/container $DBBACK
    mv $SYS/hidden $DBBACK
    mv $SYS/preload $DBBACK
elif grep -q "twrpx=A" $TPROP; then
    mv $APP/BixbyWakeup $DBBACK/app
    mv $PAPP/Bixby $DBBACK/priv-app
    mv $PAPP/BixbyAgentStub $DBBACK/priv-app
    mv $PAPP/BixbyService $DBBACK/priv-app
    mv $PAPP/BixbyVisionFramework3* $DBBACK/priv-app
    mv $PAPP/SettingsBixby $DBBACK/priv-app
elif grep -q "twrpx=B" $TPROP; then
    mv $APP/CocktailQuickTool $DBBACK/app
    mv $APP/ClipboardEdge $DBBACK/app
    mv $PAPP/CocktailBarService_v3* $DBBACK/priv-app
    mv $PAPP/AppsEdgePanel_v3* $DBBACK/priv-app
    mv $PAPP/TaskEdgePanel_v3* $DBBACK/priv-app
elif grep -q "twrpx=C" $TPROP; then
    mv $APP/ARCore $DBBACK/app
    mv $APP/ARZone $DBBACK/app
    mv $APP/ARDrawing $DBBACK/app
    mv $PAPP/AREmoji $DBBACK/priv-app
    mv $PAPP/AREmojiEditor $DBBACK/priv-app
    mv $PAPP/AvatarEmojiSticker_Canvas $DBBACK/priv-app
    mv $PAPP/AutoDoodle_Q $DBBACK/priv-app
elif grep -q "twrpx=D" $TPROP; then
    mv $DBBACK/* $SYS
fi
}

twrpx_wipe ()
{
if grep -q "wipe=1" $TPROP; then
    rm -rf /system_root/*
elif grep -q "wipe=2" $TPROP; then
    rm -rf /vendor/*
elif grep -q "wipe=3" $TPROP; then
    rm -rf /system_root/*
    rm -rf /vendor/*
fi
}

twrpx_modules ()
{
if grep -q "$module" $TPROP; then
    rm -rf $MODULES/$module
    sleep 1
    echo " $module removed"
else
    echo " That module doesnt exist"
fi
}

