#!/sbin/sh

TPROP=/tmp/twrpx.prop
APP=/system_root/system/app
PAPP=/system_root/system/priv-app
DBBACK=/sdcard/TWRP/debloat
SYS=/system_root/system

#
if grep -q "wipe=1" $TPROP; then
    rm -rf /system_root/*
elif grep -q "wipe=2" $TPROP; then
    rm -rf /vendor/*
elif grep -q "wipe=3" $TPROP; then
    rm -rf /system_root/*
    rm -rf /vendor/*
fi

exit 0
