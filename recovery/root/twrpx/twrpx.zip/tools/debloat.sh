#!/sbin/sh

TPROP=/tmp/twrpx.prop
APP=/system_root/system/app
PAPP=/system_root/system/priv-app
DBBACK=/sdcard/TWRP/debloat
SYS=/system_root/system

#
if [ ! -d "$DBBACK" ]; then
    mkdir $DBBACK
    mkdir $DBBACK/app
    mkdir $DBBACK/priv-app
fi

if grep -q "twrpx=8" $TPROP; then
    mv $APP/FBAppManager_NS $DBBACK/app
    mv $APP/FlipboardBriefing $DBBACK/app
    mv $APP/GearManagerStub $DBBACK/app
    mv $APP/SamsungPassAutofill_v1 $DBBACK/app
    mv $APP/SBrowser_12* $DBBACK/app
    mv $APP/SmartSwitchAgent $DBBACK/app
    mv $PAPP/OneDrive_Samsung_v3 $DBBACK/priv-app
    mv $PAPP/Tips $DBBACK/priv-app
    mv $PAPP/VZWAPNService_VZW $DBBACK/priv-app
elif grep -q "twrpx=9" $TPROP; then
    mv $APP/DAAgent $DBBACK/app
    mv $APP/BBCAgent $DBBACK/app
    mv $APP/BCService $DBBACK/app
    mv $APP/KnoxAttestationAgent $DBBACK/app
    mv $APP/SecurityLogAgent* $DBBACK/app
    mv $PAPP/ContainerAgent3 $DBBACK/priv-app
    mv $PAPP/DiagMonAgent $DBBACK/priv-app
    mv $PAPP/FotaAgent $DBBACK/priv-app
    mv $PAPP/KLMSAgent $DBBACK/priv-app
    mv $PAPP/knoxanalyticsagent $DBBACK/priv-app
    mv $PAPP/KnoxCore $DBBACK/priv-app
    mv $PAPP/KnoxKeychain $DBBACK/priv-app
    mv $PAPP/knoxvpnproxyhandler $DBBACK/priv-app
    mv $PAPP/SecureFolder $DBBACK/priv-app
    mv $PAPP/SKMSAgent $DBBACK/priv-app
    mv $PAPP/SOAgent $DBBACK/priv-app
    mv $APP/UniversalMDMClient $DBBACK/app
    mv $PAPP/AuthFramework $DBBACK/priv-app
    mv $PAPP/Fast $DBBACK/priv-app
    mv $PAPP/OMCAgent5 $DBBACK/priv-app
    mv $PAPP/PaymentFramework $DBBACK/priv-app
    mv $SYS/container $DBBACK
    mv $SYS/hidden $DBBACK
    mv $SYS/preload $DBBACK
elif grep -q "twrpx=A" $TPROP; then
    mv $APP/BixbyWakeup $DBBACK/app
    mv $PAPP/Bixby $DBBACK/priv-app
    mv $PAPP/BixbyAgentStub $DBBACK/priv-app
    mv $PAPP/BixbyService $DBBACK/priv-app
    mv $PAPP/BixbyVisionFramework3* $DBBACK/priv-app
    mv $PAPP/SettingsBixby $DBBACK/priv-app
elif grep -q "twrpx=B" $TPROP; then
    mv $APP/CocktailQuickTool $DBBACK/app
    mv $APP/ClipboardEdge $DBBACK/app
    mv $PAPP/CocktailBarService_v3* $DBBACK/priv-app
    mv $PAPP/AppsEdgePanel_v3* $DBBACK/priv-app
    mv $PAPP/TaskEdgePanel_v3* $DBBACK/priv-app
elif grep -q "twrpx=C" $TPROP; then
    mv $APP/ARCore $DBBACK/app
    mv $APP/ARZone $DBBACK/app
    mv $APP/ARDrawing $DBBACK/app
    mv $PAPP/AREmoji $DBBACK/priv-app
    mv $PAPP/AREmojiEditor $DBBACK/priv-app
    mv $PAPP/AvatarEmojiSticker_Canvas $DBBACK/priv-app
    mv $PAPP/AutoDoodle_Q $DBBACK/priv-app
elif grep -q "twrpx=D" $TPROP; then
    mv $DBBACK/* $SYS
fi

exit 0
